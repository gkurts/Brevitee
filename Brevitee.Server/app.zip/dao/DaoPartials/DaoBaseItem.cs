// Model is Table
using System;
using System.Data;
using System.Data.Common;
using Bryan.Apellanes;
using Bryan.Apellanes.Data;
using Bryan.Apellanes.Data.Qi;

namespace Bryan.Application.DaoTestData
{
	public partial class DaoBaseItem
	{
		  // Your code here
	}
}																								
