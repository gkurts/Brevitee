﻿$(document).ready(function () {
    //alert("yay");
});

(function ($, _, b, d) {
    "use strict";

    

    return {

    }
})(jQuery, _, bam, dao);

