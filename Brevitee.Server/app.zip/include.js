﻿; var include = {
	css:[
        
	],
    scripts: [
        "3rdParty/jasmine.js",
        "/js/testinclude.js"
    ]
};